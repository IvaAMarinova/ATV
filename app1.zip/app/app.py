from flask import Flask
from extensions import db  

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:iva123@localhost:3307/wishes'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

from model.wish import Wish
from controller.wish_controller import add_wish

# Register the add_wish function as a route
app.route('/add_wish', methods=['POST'])(add_wish)

if __name__ == '__main__':
    with app.app_context():
        # Create a new wish (For testing purposes)
        new_wish = Wish(content='Test Wish')
        db.session.add(new_wish)
        db.session.commit()

        # Query the first wish (For testing purposes)
        wish = Wish.query.first()
        print(wish.content)

    app.run(debug=True)
